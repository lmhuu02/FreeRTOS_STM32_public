/* opensslv.h compatibility */

#ifndef CYASSL_OPENSSLV_H_
#define CYASSL_OPENSSLV_H_


/* api version compatibility */
#define OPENSSL_VERSION_NUMBER 0x0090410fL


#endif /* header */

